<?php
defined('BASEPATH') or exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<!-- <meta http-equiv="refresh" content="2; URL=https://home.amikom.ac.id/" /> -->
	<title>Welcome to CodeIgniter</title>


</head>
<body>

<div id="container">
	<h1>Welcome to Welcome</h1>
</div>

</body>
</html>
