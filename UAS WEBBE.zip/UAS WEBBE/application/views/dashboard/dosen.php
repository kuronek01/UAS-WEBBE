
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">
    <script src="<?= base_url('assets/js/bootstrap.js'); ?>"></script>
    <script src="<?= base_url('assets/js/bootstrap.min.js'); ?>"></script>
    <script src="<?= base_url('assets/js/bootstrap.bundle.min.js'); ?>"></script>
    <style>
        body{
            background-color: #19376D;
        }
        .navbar{
            background-color: white;
        }
        a{
            font-size: 30px;
        }
        .left{
            width: 20%;
            height: 600px;
            background-color: white;
            margin-left: 30px;
            margin-top: 20px;
            text-align: center;
        }
        .right{
            width: 76%;
            height: 600px;
            background-color: white;
            margin-left: 20px;
            margin-top: 20px;
        }
        .row{
            width: 100%;
            
        }
        p{
          font-size: 20px;
        }
        b{
            font-size: 25px;
        }
        .logout{
            font-size: 30px;
        }
        input{
            border: none;
            background-color: #576CBC;
            width: 100%;
            height: 50px;
            border-radius: 10px;
            color: white;
            margin-top: 10px;
        }
        button{
            background-color: #453F49;
            margin-top: 20px;
            font-size: 30px;
            width: 300px;
            height: 50px;
            color: black;
            border: none;
            border-radius: 20px;
        }
        table{
          width: 100%;
        }
    </style>
</head>
<body>
<?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-error">
                <p class="error-text"><?php echo $this->session->flashdata('error'); ?></p>
            </div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success">
                <p class="success-text"><?php echo $this->session->flashdata('success'); ?></p>
            </div>
        <?php endif; ?>

    <div class="display-flex">
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="containter-fluid">
            <h2>Edit Nilai mahasiswa</h2>
            </div>
            <div class="container-fluid justify-content-end">
                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="logout nav-link active" aria-current="page" href="<?php echo base_url() . '/auth/logout'?>" style="color: black;">Logout</a>
                  </li>
                  
                </ul>
              </div>
            </div>
          </nav>
          <div class=" container-fluid display-flex">
              <div class="row">
              <div class="col-md-3 col-sm-3 mt-2 ms-5" style="background-color: white; text-align: center; overflow: scroll; height: 650px;">
              <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>NIM</th>
                    <th>Nilai</th>
                    <th>Mata Kuliah</th>
                </tr>
            </thead>
            <tbody>
                <?php

                    $nomor = 1;

                    foreach ($nilai as $siswa) {
                        echo "<tr>";
                        echo "<td>" . $nomor++ . "</td>";
                        echo "<td>" . htmlspecialchars($siswa->nama) . "</td>";
                        echo "<td>" . htmlspecialchars($siswa->user) . "</td>";
                        echo "<td>" . htmlspecialchars($siswa->score) . "</td>";
                        echo "<td>" . htmlspecialchars($siswa->matkul) . "</td>";
                        echo "</tr>";

                    }

                    //     echo "<tr><td colspan='6'>Tidak ada data ditemukan.</td></tr>";
                ?>
            </tbody>
        </table>

              </div>
              <div class="col-md-8 col-sm-8 mt-2 ms-4" style="background-color: white;">
              <form method="POST" action="<?php echo base_url() . '/mahasiswa/update_nilai'?>">
            <div class="mb-3">
                <label for="nama" class="form-label">Nama</label>
                <select class="form-select" id="nama" name="nama" required onchange="updateNilai()" >
                    <option value="">Pilih Nama</option>

                    <?php foreach ($students as $user) {
                            echo "<option value=\"" . htmlspecialchars($user->id) . "\">" . htmlspecialchars($user->nama) . "</option>";
                    }?>
                </select>
                <input type="hidden" id="nilai_id" name="nilai_id" value="">
                <input type="hidden" id="nim" name="nim" value="">
            </div>
            <div class="mb-3">
                <label for="matakuliah" class="form-label">Matakuliah</label>
                <select class="form-select" id="matakuliah" name="matakuliah" required onchange="updateNilai()">
                    <option value="">Pilih Matakuliah</option>

                    <?php foreach ($matakuliah as $mata) {
                            echo "<option value=\"" . htmlspecialchars($mata->id) . "\">" . htmlspecialchars($mata->nama) . "</option>";
                    }?>
                </select>
                <input type="hidden" id="nim" name="nim" value="">
            </div>
            <div class="mb-3">
                <label for="nilai" class="form-label">Nilai</label>
                <input type="number" class="form-control" id="nilai" name="nilai" required>
            </div>
            <button type="submit" class="btn btn-primary">Ubah Nilai</button>
        </form>

                        
              </div>
          </div>
          </div>
          </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function updateNim() {
            const namaSelect = document.getElementById('nama');
            const matakuliahSelect = document.getElementById('matakuliah');
            const nimInput = document.getElementById('nim');
            nimInput.value = namaSelect.value;
        }
        function updateNilai() {
            // Ambil nama dan matakuliah yang dipilih
            var nama = document.getElementById("nama").value;
            var matakuliah = document.getElementById("matakuliah").value;

            // Validasi jika keduanya dipilih
            if (nama && matakuliah) {
                // Ambil id mahasiswa berdasarkan nama yang dipilih
                var mahasiswa_id = nama;

                // Gunakan fetch untuk mengirimkan request POST ke server
                fetch('<?php echo base_url("mahasiswa/cek_nilai"); ?>', {
                    method: 'POST', // Metode POST
                    headers: {
                        'Content-Type': 'application/json' // Menggunakan format JSON
                    },
                    body: JSON.stringify({
                        mahasiswa_id: mahasiswa_id,  // Kirim ID mahasiswa
                        matkul_id: matakuliah       // Kirim ID matakuliah
                    })
                })
                .then(response => response.json())  // Parse JSON dari response
                .then(data => {

                    // Cek apakah nilai ditemukan
                    if (data.nilai) {
                        // Update nilai pada field nilai jika ada
                        document.getElementById("nilai").value = data.nilai.score;
                        document.getElementById('nilai_id').value = data.nilai.id;
                    } else {
                        // Jika tidak ada nilai, kosongkan input nilai
                        document.getElementById("nilai").value = '';
                    }
                })
                .catch(error => {
                    console.error('Error:', error.message);
                });
            }
        }
    </script>

</body>
</html>
