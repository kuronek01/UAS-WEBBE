<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">
    <script src="<?= base_url('assets/js/bootstrap.js'); ?>"></script>
    <script src="<?= base_url('assets/js/bootstrap.min.js'); ?>"></script>
    <script src="<?= base_url('assets/js/bootstrap.bundle.min.js'); ?>"></script>
    <style>
        body{
            background-color: #19376D;
        }
        .navbar{
            background-color: white;
        }
        a{
            font-size: 30px;
        }
        .left{
            width: 20%;
            height: 600px;
            background-color: white;
            margin-left: 30px;
            margin-top: 20px;
            text-align: center;
        }
        .right{
            width: 76%;
            height: 600px;
            background-color: white;
            margin-left: 20px;
            margin-top: 20px;
        }
        .row{
            width: 100%;
            
        }
        p{
          font-size: 20px;
        }
        b{
            font-size: 25px;
        }
        .logout{
            font-size: 30px;
        }
        input{
            border: none;
            background-color: #576CBC;
            width: 100%;
            height: 50px;
            border-radius: 10px;
            color: white;
            margin-top: 10px;
        }
        button{
            background-color: #453F49;
            margin-top: 20px;
            font-size: 30px;
            width: 300px;
            height: 50px;
            color: black;
            border: none;
            border-radius: 20px;
        }
        table{
          width: 100%;
        }
    </style>
</head>
<body>
    <div class="display-flex">
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="containter-fluid">
            <h2>Input data mahasiswa</h2>
            </div>
            <div class="container-fluid justify-content-end">
                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="logout nav-link active" aria-current="page" href="<?php echo base_url() . '/auth/logout'?>" style="color: black;">Logout</a>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
          <div class=" container-fluid display-flex">
              <div class="row">
              <div class="col-md-3 col-sm-3 mt-2 ms-5" style="background-color: white; text-align: center; overflow: scroll; height: 650px;">
              <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>NIM</th>
                        <!-- <th>Kelas</th> -->
                        <!-- <th>Mata Kuliah</th> -->
                        <!-- <th>Nilai</th> -->
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php

                        $nomor = 1;
                        if (! empty($users)) {
                            foreach ($users as $data) {
                                echo "<tr>";
                                echo "<td>" . $nomor++ . "</td>";
                                echo "<td>" . htmlspecialchars($data->nama) . "</td>";
                                echo "<td>" . htmlspecialchars($data->user) . "</td>";
                                // echo "<td>" . htmlspecialchars($data->kelas) . "</td>";
                                // echo "<td>" . htmlspecialchars($data->matakuliah) . "</td>";
                                // echo "<td>" . htmlspecialchars($data->nilai) . "</td>";
                                echo "<td>
                            <a href='javascript:void(0)' onclick='confirmDelete(\"" . htmlspecialchars($data->user) . "\")' class='btn btn-danger'><i class='bi bi-trash-fill'></i></a>
                            <a href='javascript:void(0)' onclick='openEditModal(\"" . htmlspecialchars($data->user) . "\", \"" . htmlspecialchars($data->nama) . "\", \"" . htmlspecialchars($data->id) . "\")' class='btn btn-warning btn-sm'><i class='bi bi-pencil-fill'></i></a>
                            </td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7'>Tidak ada data ditemukan.</td></tr>";
                        }
                    ?>

                </tbody>
            </table>
            
              </div>
              <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="editForm" method="POST" action="<?=base_url().'/mahasiswa/update'?>">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editModalLabel">Edit Data Mahasiswa</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="editNim" name="nim">
                        <div class="mb-3">
                            <label for="editNama" class="form-label">Nama</label>
                            <input type="text" class="form-control" id="editNama" name="nama" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

              <div class="col-md-8 col-sm-8 mt-2 ms-4" style="background-color: white;">
              <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-error">
                <p class="error-text"><?php echo $this->session->flashdata('error'); ?></p>
            </div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success">
                <p class="success-text"><?php echo $this->session->flashdata('success'); ?></p>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo base_url().'/mahasiswa/create' ?>">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="nama" class="form-label">Nama</label>
                        <input type="text" class="form-control" id="nama" name="nama" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="nim" class="form-label">NIM</label>
                        <input type="text" class="form-control" id="nim" name="nim" required>
                    </div>
                    <!-- <div class="col-md-6 mb-3">
                        <label for="kelas" class="form-label">Kelas</label>
                        <input type="text" class="form-control" id="kelas" name="kelas" required>
                    </div> -->
                    <div class="col-md-6 mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Tambah Data</button>
            </form>

                        
              </div>
          </div>
          </div>
          </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function confirmDelete(nim) {
            if (confirm("Apakah Anda yakin ingin menghapus data ini?")) {
                window.location.href = "<?=base_url().'/mahasiswa/delete'?>?delete_nim=" + nim;
            }
        }

        function openEditModal(nim, nama, id) {
            document.getElementById("editNim").value = nim;
            document.getElementById("editNama").value = nama;
            // document.getElementById("editKelas").value = kelas;
            // document.getElementById("editMatakuliah").value = matakuliah;
            new bootstrap.Modal(document.getElementById("editModal")).show();
        }
    </script>

</body>
</html>