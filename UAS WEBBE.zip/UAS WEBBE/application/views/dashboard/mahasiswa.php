<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">
    <script src="<?= base_url('assets/js/bootstrap.js'); ?>"></script>
    <script src="<?= base_url('assets/js/bootstrap.min.js'); ?>"></script>
    <script src="<?= base_url('assets/js/bootstrap.bundle.min.js'); ?>"></script>
    <style>
        body {
            background-color: #19376D;
        }
        .navbar {
            background-color: white;
        }
        a {
            font-size: 20px;
        }
        p {
            font-size: 20px;
        }
        table {
            background-color: white;
        }
        .main {
            background-color: transparent;
        }
        .logout {
            font-size: 30px;
        }
    </style>
</head>
<body>
<div class="display-flex">
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="containter-fluid">
            <h2>Dashboard</h2>
        </div>
        <div class="container-fluid justify-content-end">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="logout nav-link active" aria-current="page" href="<?php echo base_url().'/auth/logout'?>" style="color: black;">Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-error">
                <p class="error-text"><?php echo $this->session->flashdata('error'); ?></p>
            </div>
        <?php endif; ?>
        
        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success">
                <p class="success-text"><?php echo $this->session->flashdata('success'); ?></p>
            </div>
        <?php endif; ?>

<div class="main col-md-12 col-sm-8 mt-2" style="background-color: white; border-radius: 10px; overflow: scroll;">
<table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nomor</th>
                    <th>Nama</th>
                    <th>NIM</th>
                    <th>Nilai</th>
                    <!-- <th>Kelas</th> -->
                    <th>Matakuliah</th>
                </tr>
            </thead>
            <tbody>
                <?php
$nomor = 1;

foreach ($nilai as $data) {
    echo "<tr>";
    echo "<td>" . $nomor++ . "</td>"; // Tampilkan nomor urut
    echo "<td>" . htmlspecialchars($data->nama) . "</td>";
    echo "<td>" . htmlspecialchars($data->user) . "</td>";
    echo "<td>" . htmlspecialchars($data->score) . "</td>";
    // echo "<td>" . htmlspecialchars($data->kelas) . "</td>";
    echo "<td>" . htmlspecialchars($data->matkul) . "</td>";
    echo "</tr>";
}

?>
            </tbody>
        </table>
</div>
</body>
</html>
