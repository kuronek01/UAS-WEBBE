
          <div class="header-kanan">
            <div class="jdl m-0">
              <b><h2 class="m-0 bg-white p-3">DASHBOARD DOSEN</h2></b>
            </div>
          </div>
          <hr />
          <!-- MENU KANAN -->
          <div class="sem"><h4>Semester - Genap TA. 2023/2024</h4></div>
          <div class="menud">
            <div class="card cardqr">
              <div class="qrc">QR DOSEN</div>
              <hr />
              <div class="d-flex justify-content-center">
                <img class="imgqr" src="<?=base_url() . 'assets/qr.png'?>" alt="image" />
              </div>
            </div>
            <div class="card cardaktif">
              <div class="qrc">STATUS AKTIVASI</div>
              <hr />
              <div class="d-flex align-items-center justify-content-center">
                <img class="imgck" src="<?=base_url() . 'assets/ck.png'?>" alt="image" />
                <div class="tif">
                  <b><h2>Aktif</h2></b>
                </div>
              </div>
            </div>
            <div class="card cardmatkul">
              <div class="qrc">DAFTAR AJAR MATAKULIAH</div>
              <hr />
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Matakuliah</th>
                    <th>Kelas</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>1</td>
                    <td class="mtkl">Pemrograman Web</td>
                    <td>23D3TI01</td>
                  </tr>
                  <tr>
                    <td>2</td>
                    <td class="mtkl">Keamanan Data</td>
                    <td>23D3TI03</td>
                  </tr>
                  <tr>
                    <td>3</td>
                    <td class="mtkl">Struktur Data</td>
                    <td>23S1SI05</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="mtkulcard">
            <div class="jadwalpengajaran">
              <p><b>JADWAL PENGAJARAN</b></p>
            </div>
            <div class="card cardjadwal">
              <div class="jadwal">
                <i class="bi bi-calendar-check-fill iconnih"></i>
                <div class="jadwalajar">
                  <p><b>Selasa</b></p>
                  <p>Pemrograman Web</p>
                </div>
                <div class="jamajar">
                  <p>08.50-10.30</p>
                  <p>07.04.01</p>
                </div>
              </div>
              <hr />
              <div class="jadwal">
                <i class="bi bi-calendar-check-fill iconnih"></i>
                <div class="jadwalajar">
                  <p><b>Selasa</b></p>
                  <p>Keamanan Data</p>
                </div>
                <div class="jamajar">
                  <p>10.40-12.20</p>
                  <p>07.04.02</p>
                </div>
              </div>
              <hr />
              <div class="jadwal">
                <i class="bi bi-calendar-check-fill iconnih"></i>
                <div class="jadwalajar">
                  <p><b>Rabu</b></p>
                  <p>Struktur Data</p>
                </div>
                <div class="jamajar">
                  <p>10.40-12.20</p>
                  <p>05.04.03</p>
                </div>
              </div>
              <hr />
              <div class="jadwal">
                <i class="bi bi-calendar-check-fill iconnih"></i>
                <div class="jadwalajar">
                  <p><b>Rabu</b></p>
                  <p>Pemrograman Web</p>
                </div>
                <div class="jamajar">
                  <p>13.20-15.00</p>
                  <p>07.02.01</p>
                </div>
              </div>
            </div>
          </div>
