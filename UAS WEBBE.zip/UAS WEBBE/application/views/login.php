<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="icon" href="img/lb_icon.png" type="image/png">
 <title>Login</title>
 <style>
 body {
 font-family: Arial, sans-serif;
 background-color: #81C6C2;
 margin: 0;
 padding: 0;
 display: flex;
 justify-content: center;
 align-items: center;
 height: 100vh;
 }
 .login-container {
 display: flex;
 background-color: #B83D5B;
 box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.2);
 border-radius: 10px;
 overflow: hidden;
 width: 800px;
 }
a{
    color: white;
}

 .image-section {
 flex: 1;
 background-image: url('<?= base_url('assets/Yumia.gif');?>');
 background-size: cover;
 background-position: center;
 }
 .form-section {
 flex: 1;
 padding: 40px;
 display: flex;
 flex-direction: column;
 justify-content: center;
 }
 .form-section h2 {
 margin-bottom: 30px;
 text-align: center;
 font-size: 24px;
 display: flex;
 justify-content: center;
 align-items: center;
 gap: 10px;
 }
 .form-section h2 img {
 width: 30px;
 height: 30px;
 }
 .form-section input {
 width: 100%;
 padding: 10px;
 margin-bottom: 20px;
 border: 1px solid #ccc;
 border-radius: 5px;
 font-size: 16px;
 }
 .form-section button {
 width: 40%;
 padding: 10px;
 background-color: #453F49;
 color: white;
 border: none;
 border-radius: 5px;
 font-size: 16px;
 cursor: pointer;
 }
 .form-section button:hover {
 background-color: #b33d3d;
 }
 .form-section a {
 color: white;
 text-decoration: none;
 text-align: left;
 display: block;
 margin-top: 10px;
 }
 </style>
</head>
<body>

 <div class="login-container">
 <div class="image-section">
    
 </div>
 <div class="form-section">
 <h2>
 <img src="<?= base_url('assets/puni.WEBP'); ?>" alt="Icon">
 Sign into your account
 </h2>
 <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-error">
                <p class="error-text"><?php echo $this->session->flashdata('error'); ?></p>
            </div>
        <?php endif;?>
 <form action=" <?=base_url() . 'auth/action_login'?>" method="POST">
 <input type="text" name="username" placeholder="Username/NIM">
 <input type="password" name="password"
placeholder="Password">
 <button type="submit">Login</button>
 </form>
 <a href="#">Forgot password?</a>
 <a href="Register.php">Don't have an account? Register here</a>
 </div>
 </div>
</body>
</html>